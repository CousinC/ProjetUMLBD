CREATE PROCEDURE nouvellePersonne(p_nomPersonne IN Personnes.nomPersonne%TYPE, p_prenomPersonne IN Personnes.prenomPersonne%TYPE, p_villePersonne IN Personnes.villePersonne%TYPE) IS
BEGIN
	INSERT INTO Personnes(numPersonne, nomPersonne, prenomPersonne, villePersonne) VALUES (seqPersonne.NEXTVAL, p_nomPersonne, p_prenomPersonne, p_villePersonne);
END;
/

