CREATE FUNCTION CATotalParClient (p_numeroClient IN Clients.numeroClient%TYPE)
		RETURN NUMBER IS
v_CATotalClient NUMBER;
BEGIN
	SELECT SUM(montantAchat) INTO v_CATotalClient
	FROM Achats
	WHERE numeroClient = p_numeroClient
	GROUP BY numeroClient;
	RETURN v_CATotalClient;
END;
/

