CREATE PROCEDURE insertionClient (p_nomClient IN Clients.nomClient%TYPE, p_prenomClient IN Clients.prenomClient%TYPE, p_villeClient IN Clients.villeClient%TYPE) IS
BEGIN
	INSERT INTO Clients(numeroClient, nomClient, prenomClient, categorieClient, villeClient) VALUES (seqClients.NEXTVAL, p_nomClient, p_prenomClient, 'PROSPECTS', p_villeClient);
END;
/

