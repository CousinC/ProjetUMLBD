CREATE TRIGGER TRIG_VERIF_NBVENDEURPARCLIENT
  BEFORE INSERT
  ON ETRESUIVI
  FOR EACH ROW
  DECLARE
	v_nbVendeur NUMBER;
BEGIN
	SELECT COUNT(*) INTO v_nbVendeur
	FROM EtreSuivi
	WHERE numeroClient = :NEW.numeroClient;
	IF v_nbVendeur = 2 THEN
		RAISE_APPLICATION_ERROR (-20002, 'Action impossible, le client est déjà suivi par 2 vendeurs');
	END IF;
END;
/

